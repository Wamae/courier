<?php $__env->startSection('content'); ?>

<link rel="stylesheet" href="<?php echo e(asset('css/client_reports.css')); ?>">
<div class="panel panel-default">
    <div class="panel-heading" align="center">
        <b><?php echo e(config('app.name', 'Laravel')); ?> CLIENT REPORTS</b>
    </div>

    <div class="panel-body">
        <div class="non-print search-panel ">
            <div>
                <table class="table table-striped table-responsive table-condensed" border="1" cellpadding="0" cellspacing="0" style="border-collapse:collapse;">
                    <thead>
                        <tr>
                            <th></th>
                            <th>CLIENT NAME</th>
                            <th colspan="3">TO BE INVOICED</th>
                            <th colspan="3">INVOICED PAYMENTS</th>
                        </tr>
                        <tr>
                            <th></th>
                            <th></th>
                            <th>AMOUNT</th>
                            <th>V.A.T</th>
                            <th>TOTAL</th>
                            <th>AMOUNT</th>
                            <th>V.A.T</th>
                            <th>TOTAL</th>
                        </tr>
                    </thead>
                    <tbody> 
                        <?php $totalAmount = 0;
                        $totalVAT = 0;
                        $totalVATAmount = 0; 
                        $currency = "";
                        ?>
                        <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($invoice->client_name); ?></td>
                            <td><?php echo e($invoice->currency); ?> <?php echo e(number_format($invoice->total_amount,2)); ?></td>
                            <td><?php echo e($invoice->currency); ?> <?php echo e(number_format($invoice->total_vat,2)); ?></td>
                            <td><?php echo e($invoice->currency); ?> <?php echo e(number_format(($invoice->total_amount + $invoice->total_vat),2)); ?></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <?php
                        $totalAmount += $invoice->total_amount;
                        $totalVAT += $invoice->total_vat;
                        $totalVATAmount += ($invoice->total_vat + $invoice->total_amount);
                        $currency = $invoice->currency;
                        ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td></td>
                            <td>TOTAL</td>
                            <td><?php echo e($currency); ?> <?php echo e(number_format($totalAmount,2)); ?></td>
                            <td><?php echo e($currency); ?> <?php echo e(number_format($totalVAT,2)); ?></td>
                            <td><?php echo e($currency); ?> <?php echo e(number_format($totalVATAmount,2)); ?></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">


</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>