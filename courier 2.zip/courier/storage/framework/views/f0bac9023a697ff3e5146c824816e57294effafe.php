<?php $__env->startSection('content'); ?>


<h2 class="page-header">Manifest</h2>

<div class="panel panel-default">
    <div class="panel-heading">
        Add/Modify  Manifest    </div>

    <div class="panel-body">

        <form action="<?php echo e(url('/manifests'.( isset($model) ? "/" . $model->id : ""))); ?>" method="POST" class="form-horizontal">
            <?php echo e(csrf_field()); ?>


            <?php if(isset($model)): ?>
            <input type="hidden" name="_method" value="PATCH">
            <?php endif; ?>


            <div class="form-group hidden">
                <label for="id" class="col-sm-3 control-label">Id</label>
                <div class="col-sm-6">
                    <input type="text" name="id" id="id" class="form-control" value="<?php echo e(isset($model['id']) ? $model['id'] : ''); ?>" readonly="readonly">
                </div>
            </div>
            <div class="form-group">
                <label for="origin" class="col-sm-3 control-label">Origin</label>
                <div class="col-sm-2">
                    <input type="hidden" name="origin" class="form-control" id="origin" value="<?php echo e(Auth::user()->station); ?>" readonly/>
                    <input name="origin_name" class="form-control" id="origin_name" value="<?php echo e(Auth::user()->stations->office_name); ?>" readonly/>
                </div>
            </div>
            <div class="form-group">
                <label for="destination" class="col-sm-3 control-label">Destination</label>
                <div class="col-sm-2">
                    <select name="destination" class="form-control">
                        <option value="">Select a station</option>
                        <?php $__currentLoopData = $stations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $station): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php echo e((isset($model))?($model['destination'] == $station->id)?'selected':'':''); ?> value="<?php echo e($station->id); ?>"><?php echo e($station->office_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label for="registration no" class="col-sm-3 control-label">Registration No</label>
                <div class="col-sm-6">
                    <input type="text" name="registration no" id="registration no" class="form-control" value="<?php echo e(isset($model['registration_no']) ? $model['registration_no'] : ''); ?>">
                </div>
            </div>
            <div class="form-group">
                <label for="driver" class="col-sm-3 control-label">Driver</label>
                <div class="col-sm-6">
                    <input type="text" name="driver" id="driver" class="form-control" value="<?php echo e(isset($model['driver']) ? $model['driver'] : ''); ?>">
                </div>
            </div>
            <div class="form-group">
                <label for="conductor" class="col-sm-3 control-label">Conductor</label>
                <div class="col-sm-6">
                    <input type="text" name="conductor" id="conductor" class="form-control" value="<?php echo e(isset($model['conductor']) ? $model['conductor'] : ''); ?>">
                </div>
            </div>
            <div class="form-group">
                <label for="status" class="col-sm-3 control-label">Status</label>
                <div class="col-sm-2">
                    <select name="status" class="form-control">
                        <?php $__currentLoopData = $manifest_status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php echo e((isset($model))?($model['status'] == $status->id)?'selected':'':''); ?> value="<?php echo e($status->id); ?>"><?php echo e($status->status); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                        
                    </select>
                </div>
            </div>

            <div class="form-group">
                <div class="col-sm-offset-3 col-sm-6">
                    <button type="submit" class="btn btn-success">
                        <i class="fa fa-plus"></i> Save
                    </button> 
                    <a class="btn btn-default" href="<?php echo e(url('/manifests')); ?>"><i class="glyphicon glyphicon-chevron-left"></i> Back</a>
                </div>
            </div>
        </form>

    </div>
</div>






<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>