<?php $__env->startSection('content'); ?>


<h2 class="page-header"><?php echo e(ucfirst('manifests')); ?></h2>

<div class="panel panel-default">
    <div class="panel-heading">
        List of <?php echo e(ucfirst('manifests')); ?>

    </div>

    <div class="panel-body">
        <div class="">
            <table class="table table-striped" id="thegrid">
              <thead>
                <tr>
                                        <th>Id</th>
                                        <th>Loading Manifest</th>
                                        <th>Date</th>
                                        <th>Origin</th>
                                        <th>Destination</th>
                                        <th>Created By</th>                                        
                                        <th>Loaded</th>
                                        <th>Status</th>
                                        <th style="width:50px"></th>
                    <th style="width:50px"></th>
                </tr>
              </thead>
              <tbody>
              </tbody>
            </table>
        </div>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create manifest')): ?>
        <a href="<?php echo e(url('manifests/create')); ?>" class="btn btn-primary" role="button">Create loading manifest</a>
        <?php endif; ?>
    </div>
</div>




<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
        var theGrid = null;
        $(document).ready(function(){
            theGrid = $('#thegrid').DataTable({
                "processing": true,
                "serverSide": true,
                "ordering": true,
                "responsive": true,
                "ajax": "<?php echo e(url('manifests/grid')); ?>",
                "columns": [
                    { "data": "id","name": "a.id"},
                    { "data": "loading_manifest","name": "a.manifest_no","targets": 1,"render": function ( data, type, row ) {
                            return "<a href='<?php echo e(url('manifests')); ?>/'"+row[0]+"'>"+data+"</a>";
                        }
                    },
                    { "data": "created_at","name": "a.created_at"},
                    { "data": "origin","name": "cs.office_name"},
                    { "data": "destination","name": "cs2.office_name"},
                    { "data": "created_by","name": "u.name"},
                    { "data": "loaded","render": function ( data, type, row ) {
                            return `<a class="btn btn-info btn-xs" href="<?php echo e(url('waybill_manifests')); ?>/${row['id']}"> ${data} items</a>`;
                        },
                        "targets": 6, "searchable": false},
                    { "data": "status","targets": 7,"name": "ms.status"},
                    { "data": "X",
                        "targets": 8 ,"render": function ( data, type, row ) {
                                    return `<a href="<?php echo e(url('manifests')); ?>/print_manifest/pdf?id=${row['id']} " class="btn btn-status btn-xs btn-success"><span class="glyphicon glyphicon-print"></span> Print</a>`;
                        }, "searchable": false
                    },
                    { "data": "Y", "searchable": false}

                ]
            });
        });
        function doDelete(id) {
            if(confirm('You really want to delete this record?')) {
               $.ajax({ url: "<?php echo e(url('manifests')); ?>/" + id, type: 'DELETE'}).success(function() {

                theGrid.ajax.reload();
               });
            }
            return false;
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>