<?php $__env->startSection('content'); ?>

<div class="panel panel-default">
    <div class="panel-heading">
        <?php echo e((isset($model)?"UPDATE WAYBILL":"CREATE WAYBILL")); ?>    </div>

    <div class="panel-body">

        <form id="form-add-waybill" action="<?php echo e(url('/waybills'.( isset($model) ? "/" . $model->id : ""))); ?>" method="POST" class="form-horizontal">
            <?php echo e(csrf_field()); ?>


            <?php if(isset($model)): ?>
            <input type="hidden" name="_method" value="PATCH">
            <?php endif; ?>


            <div class="modal-header">
                <div class="form_heading">WAYBIL INFORMATION DETAILS</div>
            </div>
            <div class="modal-body">
                <!-- MODAL BODY -->
                <table width="100%">
                    <tr>
                        <td valign="top" width="50%">
                            <!-- xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx -->

                            <div class="form-group hidden">
                                <label for="id" class="col-sm-3 control-label">Id</label>
                                <div class="col-sm-6">
                                    <input type="text" name="id" id="id" class="form-control" value="<?php echo e(isset($model['id']) ? $model['id'] : ''); ?>" readonly="readonly">
                                </div>
                            </div>

                            <div class="control-group form-group">
                                <!--   ---->
                                <label class="col-lg-4 control-label" for="consignor_name">CONSIGNOR:<sup>*</sup></label>

                                <!--   ---->
                                <!-- <label class="col-lg-4 control-label" for="consignor_name">CONSIGNOR:<sup>*</sup></label> ---->
                                <div class="col-lg-8 non-acc" id="consignor-div">
                                    <input type="text" name="consignor" required id="consignor" class="form-control" value="<?php echo e(isset($model['consignor']) ? $model['consignor'] : ''); ?>">
                                </div>
                            </div>

                            <div class="control-group form-group">
                                <label class="col-lg-4 control-label" for="consignor_name">CONSIGNOR TEL:<sup>*</sup></label>

                                <div class="col-lg-8 non-acc" id="consignor-tel-div">
                                    <input type="text" name="consignor_tel" required id="consignor-tel" class="form-control" value="<?php echo e(isset($model['consignor_tel']) ? $model['consignor_tel'] : ''); ?>">
                                </div>
                            </div>

                            <div class="control-group form-group">
                                <label class="col-lg-4 control-label" for="consignor_name">CONSIGNEE:<sup>*</sup></label>
                                <div class="col-lg-8">
                                    <input type="text" name="consignee" required id="consignee" class="form-control" value="<?php echo e(isset($model['consignee']) ? $model['consignee'] : ''); ?>">
                                </div>
                            </div>

                            <div class="control-group form-group">
                                <label class="col-lg-4 control-label" for="consignor_name">CONSIGNEE TEL:<sup>*</sup></label>
                                <div class="col-lg-8">
                                    <input type="text" name="consignee_tel" required id="consignee-tel" class="form-control" value="<?php echo e(isset($model['consignee_tel']) ? $model['consignee_tel'] : ''); ?>">
                                </div>
                            </div>

                            <div class="control-group form-group">
                                <!--<label class="col-lg-4 control-label" for="origin">ORIGIN:<sup>*</sup></label>-->
                                <div class="col-lg-8">
                                    <!--<select name="origin" class="form-control">
                                        <?php $__currentLoopData = $stations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $station): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php echo e((isset($model))?($model['origin'] == $station->id)?'selected':'':''); ?> value="<?php echo e($station->id); ?>"><?php echo e($station->office_name); ?></option>   
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>-->
                                    <input type="hidden" name="origin" required id="origin" class="form-control" value="<?php echo e(isset($model['origin'])?$model['origin']:Auth::user()->station); ?>">
                                </div>
                            </div>

                            <div class="control-group form-group">
                                <label class="col-lg-4 control-label" for="$stations">DESTINATION:<sup>*</sup></label>
                                <div class="col-lg-8">
                                    <select name="destination" class="form-control">
                                        <?php $__currentLoopData = $stations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $station): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php echo e((isset($model))?($model['destination'] == $station->id)?'selected':'':''); ?> value="<?php echo e($station->id); ?>"><?php echo e($station->office_name); ?></option>   
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select></div>
                            </div>
                            <div class="control-group form-group">
                                <label class="col-lg-4 control-label" for="package_type">PACKAGE TYPE:<sup>*</sup></label>
                                <div class="col-lg-8">
                                    <select name="package_type" required id="package_type" data-live-search="true" class="form-control selectpicker">
                                        <?php $__currentLoopData = $package_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php echo e((isset($model))?($model['package_type'] == $package_type->id)?'selected':'':''); ?> value="<?php echo e($package_type->id); ?>"><?php echo e($package_type->package_type); ?></option>   
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="control-group form-group">
                                <label class="col-lg-4 control-label" for="quantity">QUANTITY:<sup>*</sup></label>
                                <div class="col-lg-8">
                                    <input type="number" name="quantity" required min="1" required id="quantity" class="form-control" value="<?php echo e(isset($model['quantity']) ? $model['quantity'] : ''); ?>"/>
                                </div>
                            </div>
                            <!-- xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx -->
                        </td>
                        <td valign="top" width="50%">
                            <!-- xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx -->
                            <div class="control-group form-group">
                                <label class="col-lg-4 control-label" for="weight">WEIGHT:</label>
                                <div class="col-lg-3">
                                    <input type="text" id="weight" name="weight" placeholder=" e.g 5 KGS" class="form-control" value="<?php echo e(isset($model['weight']) ? $model['weight'] : ''); ?>">
                                </div>
                                <label class="col-lg-2 control-label" for="cbm">CBM:</label>
                                <div class="col-lg-3">
                                    <input type="text" id="cbm" name="cbm" placeholder=" e.g 2 CBM" class="form-control" value="<?php echo e(isset($model['cbm']) ? $model['cbm'] : ''); ?>">
                                </div>
                            </div>
                            <div class="control-group form-group">
                                <label class="col-lg-4 control-label" for="consignor_name">CONSIGNOR EMAIL:</label>
                                <div class="col-lg-8">
                                    <input type="text" id="consignor_email" name="consignor_email" placeholder="e.g. name@gmail.com" class="form-control" value="<?php echo e(isset($model['consignor_email']) ? $model['consignor_email'] : ''); ?>">
                                </div>
                            </div>
                            <div class="control-group form-group">
                                <label class="col-lg-4 control-label" for="description">DESCRIPTION:</label>
                                <div class="controls col-lg-8">
                                    <textarea name="description" id="description" class="form-control" placeholder="Write a comment that may be useful in the shipping process"><?php echo e(isset($model['description']) ? $model['description'] : ''); ?></textarea>
                                </div>
                            </div>
                            <div class="control-group form-group">
                                <label class="col-lg-4 control-label" for="payment_mode">PAYMENT MODE:<sup>*</sup></label>
                                <div class="col-lg-8">
                                    <select name="payment_mode" required id="payment-mode"  data-live-search="true" class="form-control selectpicker">
                                        <?php $__currentLoopData = $payment_modes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment_mode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php echo e((isset($model))?($model['payment_mode'] == $payment_mode->id)?'selected':'':''); ?> value="<?php echo e($payment_mode->id); ?>"><?php echo e($payment_mode->payment_mode); ?></option>   
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>   </div>
                            </div>
                            <div class="form-group">
                                <label class="col-lg-4 control-label" for="per_item">AMOUNT PER ITEM:<sup>*</sup></label>
                                <div class="col-lg-4">
                                    <select name="currency_perItem" id="currency_perItem" class="form-control selectpicker">
                                        <option value="ksh" selected="selected">KSH</option>
                                    </select>   </div>
                                <div class="col-lg-4">
                                    <input type="number" min="100" required id="amount_per_item" name="amount_per_item" class="form-control" value="<?php echo e(isset($model['amount_per_item']) ? $model['amount_per_item'] : ''); ?>">
                                </div>
                            </div>
                            <div class="control-group form-group">
                                <label class="col-lg-4 control-label" for="vat"> INCLUDED V.A.T (16.0%):</label>
                                <input id="vat-per" value="16" hidden="true" type="number"/>

                                <div class="col-lg-4">
                                    <select name="currency_vat" id="currency_vat" class="form-control selectpicker">
                                        <option value="ksh" selected="selected">KSH</option>
                                    </select>   </div>

                                <div class="col-lg-4">
                                    <input type="text" id="vat" name="vat" readonly="readonly" class="form-control" value="">
                                </div>
                            </div>
                            <div class="control-group form-group">
                                <label class="col-lg-4 control-label" for="amount"> AMOUNT:</label>

                                <div class="col-lg-4">
                                    <select name="currency" id="currency" class="form-control selectpicker">
                                        <option value="ksh" selected="selected">KSH</option>
                                    </select>   </div>

                                <div class="col-lg-4">
                                    <input type="text" id="amount" name="amount" readonly="readonly" class="form-control" value="<?php echo e(isset($model['amount']) ? $model['amount'] : ''); ?>">
                                </div>

                            </div>
                        </td>
                    </tr>
                </table>

            </div>

            <div class="modal-footer">
                <div class="btn-group">
                    <a class="btn btn-warning cancel-btn receiver-info" href="<?php echo e(url('/waybills')); ?>"><i class=""></i>BACK</a>
                    <button id="create-waybill" type="submit" class="btn btn-primary add-waybil-btn receiver-info">
                        <i class="fa fa-plus"></i><?php echo e((isset($model)?"UPDATE WAYBILL":"CREATE WAYBILL")); ?>

                    </button> 
                </div>
            </div>

    </div>
</form>             
</div>
</div>

<?php $__env->startSection('scripts'); ?>
<script>
    $(function () {
        $("#form-add-waybill").submit(function(event){
            event.preventDefault();
            
            amount = $("#amount_per_item").val();
            consignor = $("#consignor").val();

            swal({
                title: 'PLEASE CONFIRM THAT YOU HAVE RECEIVED KSH'+amount+' FROM '+consignor,
                text: "ARE YOU SURE THAT YOU WANT TO CONTINUE?!",
                type: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#00FF7F',
                cancelButtonColor: '#D33',
                confirmButtonText: 'Recieved'
              }).then((result) => {
                if (result.value) {
                     $(this).unbind('submit').submit();
                }
              });
        });
        $("#amount_per_item").keyup(function () {
            vatPer = $("#vat-per").val();

            amountPerItem = $(this).val();
            vatAmount = (vatPer / 100) * amountPerItem;
            $("#vat").val(vatAmount);
            finalAmount = Math.ceil(amountPerItem - vatAmount);

            $("#amount").val(finalAmount);
        });

        $("#payment-mode").change(function () {
            paymentMode = $(this).val();
            //if(paymentMode == 4){
            changeConsignorDetails(paymentMode);
            //}
        });

        function changeConsignorDetails(paymentMode) {
            if (paymentMode == 4) {
                $.ajax({
                    url: "<?php echo e(url('clients/getClients/all')); ?>",
                    dataType: "JSON",
                    success: function (clients) {
                        clientOptions = `<select id='consignor' name='client_id' 
                onchange='consignorUpdate(this.options[this.selectedIndex].getAttribute("phone"))' class='form-control'>`;
                        for (i = 0; i < clients.length; i++) {
                            clientOptions += `<option phone='${clients[i].client_telephone}' value='${clients[i].id}'>${clients[i].client_name}</option>`;
                        }
                        $("#consignor-div").html(clientOptions);
                        
                        $("#consignor-tel").val(clients[0].client_telephone);
                         $("#consignor-tel").attr("readonly", true);

                    }
                });

            } else {
            
                htmlString = '<input type="text" name="consignor_tel" required id="consignor_tel" class="form-control" value="<?php echo e(isset($model["consignor_tel"]) ? $model["consignor_tel"] : ""); ?>">';
                $("#consignor-tel-div").html(htmlString);
                
                $("#consignor-div").html('<input type="text" name="consignor" required id="consignor" class="form-control" value="<?php echo e(isset($model['consignor']) ? $model['consignor'] : ''); ?>">');
            }
        }
    });

    function consignorUpdate(phone) {
        console.log(phone);
        $("#consignor-tel").val(phone);
    }
</script>
<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>