<?php
header("Location: http://localhost/courier/public"); /* Redirect browser */