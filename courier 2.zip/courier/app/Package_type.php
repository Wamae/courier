<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Package_type extends Model
{
    //
}
