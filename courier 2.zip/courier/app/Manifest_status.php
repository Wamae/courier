<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Manifest_status extends Model
{
    
}
